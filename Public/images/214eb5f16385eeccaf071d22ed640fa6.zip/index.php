<?php
define('THINK_PATH','./ThinkPHP/');
define('APP_NAME','App');
define('APP_PATH','./App/');
define('APP_DEBUG',true);
//define('SAE_RUNTIME',true);
require THINK_PATH.'Extend/Engine/Sae.php';
